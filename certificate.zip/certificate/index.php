<?php
$con = mysqli_connect('localhost','root','','msam');
$query = "SELECT * FROM user" ;
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_array($result)){

header('Content-type: image/jpeg');
//Font
$fonts=realpath('Parisienne-Regular.ttf');
$font=realpath('arial.ttf');
//Image File
$image=imagecreatefromjpeg("ms.jpg");
//Text Color
$color=imagecolorallocate($image, 51, 51, 102);
//Date
$date=date('d F, Y');
imagettftext($image, 12, 0, 440, 135, $color,$font, $date);
//Data Query from Database
$name= $row['username'];
imagettftext($image, 10, 0, 180, 188, $color,$fonts, $name);
//Data text
$fname= 'Harun-Or-Rashid';
imagettftext($image, 10, 0, 180, 220, $color,$fonts, $fname);
$Class= 'Six';
imagettftext($image, 10, 0, 180, 257, $color,$fonts, $Class);
$Roll= '101';
imagettftext($image, 10, 0, 180, 295, $color,$fonts, $Roll);
$Quran_m= '80';
imagettftext($image, 10, 0, 315, 485, $color,$font, $Quran_m);
$Quran_gp= 'A+';
imagettftext($image, 10, 0, 420, 485, $color,$font, $Quran_gp);
$Quran_g= '5.00';
imagettftext($image, 10, 0, 520, 485, $color,$font, $Quran_g);
$Feqa_m= '80';
imagettftext($image, 10, 0, 315, 511, $color,$font, $Feqa_m);
$Feqa_gp= 'A+';
imagettftext($image, 10, 0, 420, 511, $color,$font, $Feqa_gp);
$Feqa_g= '5.00';
imagettftext($image, 10, 0, 520, 511, $color,$font, $Feqa_g);

imagejpeg($image);
imagedestroy($image);

}
?>

